//
//  HTCustomizedAESencrypt.h
//  libHTAESencrypt
//
//  Created by yangzhexu on 22/01/2018.
//  Copyright © 2018 yangzhexuxjtu. All rights reserved.
//

#ifndef HTCustomizedAESencrypt_h
#define HTCustomizedAESencrypt_h

#import "AESCrypt.h"
#import "libHTAESencrypt.h"

#endif /* HTCustomizedAESencrypt_h */
